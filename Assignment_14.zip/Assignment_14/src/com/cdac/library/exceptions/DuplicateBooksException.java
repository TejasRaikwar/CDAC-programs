package com.cdac.library.exceptions;

public class DuplicateBooksException extends Exception{
	public DuplicateBooksException(String msg){
		super(msg);
	}
}
