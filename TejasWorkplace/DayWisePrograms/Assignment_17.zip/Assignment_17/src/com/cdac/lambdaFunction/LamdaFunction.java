package com.cdac.lambdaFunction;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.IntStream;

public class LamdaFunction {
	public static void main(String[] args) {
		Function<String,LocalDate> fun=(x)->LocalDate.parse(x);
		System.out.println(fun.apply("1999-12-12"));
		
		BiFunction<String,String,LocalDate> binfn=(x,y)->LocalDate.parse(x,DateTimeFormatter.ofPattern(y));
		System.out.println(binfn.apply("20-08-2010","dd-MM-yyyy"));

		Predicate<Integer> pre=(x)->x%2==0;
		System.out.println(pre.test(51));
		
		IntStream.rangeClosed(500, 510).forEach(System.out::println);
	}
}
