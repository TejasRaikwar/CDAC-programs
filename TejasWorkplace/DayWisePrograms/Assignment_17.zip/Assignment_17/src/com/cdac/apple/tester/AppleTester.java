package com.cdac.apple.tester;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.cdac.apple.Apple;
import com.cdac.apple.Utils.AppleUtil;

public class AppleTester {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		List<Apple> farm=new ArrayList<>();
		farm.addAll(AppleUtil.getApple());
		
		int n;
		do {
			System.out.println("Enter Option :");
			System.out.println("1.Filter by Weight");
			System.out.println("2.Filter by Color");
			System.out.println("3.filter by Color and Weight");
			System.out.println("4.filter by Color, Weight and Taste");
			System.out.println("5.Sort by Weight");
			System.out.println("6.Sort by Color");
			System.out.println("7.Remove Red Apples");
			System.out.println("8.Remove Green Apples");
			System.out.println("9.Convert to Set collection");
			System.out.println("0.Exit");
			n=sc.nextInt();
			switch(n) {
			case 1:{
				//1.     Filter by weight
				System.out.println("Enter the Weight of apple :");
				double weight=sc.nextDouble();
				
				farm.stream().filter((apple)->apple.getWeight()==weight).forEach(System.out::println);
				
				break;
			}
			case 2:{
				//2.     filter by color
				System.out.println("Enter the Color of apple :");
				String color=sc.next();
				farm.stream().filter((apple)->apple.getColor()==color).forEach(System.out::println);
				break;
			}
			case 3:{
				//3.     filter by color and weight
				System.out.println("Enter the Weight of apple :");
				double weight=sc.nextDouble();
				System.out.println("Enter the Color of apple :");
				String color=sc.next();
				farm.stream().filter((apple)-> apple.getColor()==color).filter((apple)->apple.getWeight()==weight).forEach(System.out::println);
				break;
			}
			case 4:{
				//4.     filter by color, weight and taste
				System.out.println("Enter the Weight of apple :");
				double weight=sc.nextDouble();
				System.out.println("Enter the Color of apple :");
				String color=sc.next();
				System.out.println("Enter the Taste of apple :");
				String taste=sc.next();
				farm.stream().filter((apple)-> apple.getColor()==color).filter((apple)->apple.getWeight()==weight).filter((apple)->apple.getTaste()==taste).forEach(System.out::println);
				break;
			}
			case 5:{
				//5.     Sort by weight
				farm.stream().sorted((a1,a2)->a1.getWeight().compareTo(a2.getWeight())).forEach(System.out::println);
				break;
			}
			case 6:{
				//6.     Sort by color
				farm.stream().sorted((a1,a2)->a1.getColor().compareTo(a2.getColor())).forEach(System.out::println);
				
				break;
			}
			case 7:{
				//7.     Remove red apples
				farm.stream().filter((apple)->!apple.getColor().equals("RED")).forEach(System.out::println);
				break;
			}
			case 8:{
				//8.     Removed Green apples
				farm.stream().filter((apple)->!apple.getColor().equals("GREEN")).forEach(System.out::println);
				break;
			}
			case 9:{
				//9.     Convert to Set collection
				System.out.println("Converted To Set");
				farm.stream().collect(Collectors.toSet()).forEach(System.out::println);
				break;
			}
			case 0:{
				System.out.println("Thank You For Visiting Apple Farm");
				break;
			}
			default:
				System.out.println("Invalid Input");
			
			}
			
			
		}while(n!=0);
	}
 
}
