
//1) Create Apple class with weight, color and taste. Use Stream API for below things. Use method ref for println
//1.     Filter by weight
//2.     filter by color
//3.     filter by color and weight
//4.     filter by color, weight and taste
//5.     Sort by weight
//6.     Sort by color
//7.     Remove red apples
//8.     Removed Green apples
//9.     Convert to Set collection
package com.cdac.apple;

import java.util.Objects;

public class Apple {
	private Double weight;
	@Override
	public int hashCode() {
		return Objects.hash(color, taste);
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Apple other = (Apple) obj;
		return Objects.equals(color, other.color) && Objects.equals(taste, other.taste);
	}

	private String color;
	private String taste;
	
	
	private Apple() {
		super();
	}
	
	

	public Apple(Double weight, String color, String taste) {
		super();
		this.weight = weight ;
		this.color = color.toUpperCase();
		this.taste = taste.toUpperCase();
	}

	/**
	 * @return the weight
	 */
	public Double getWeight() {
		return weight;
	}
	/**
	 * @param weight the weight to set
	 */
	public void setWeight(Double weight) {
		this.weight = weight;
	}
	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}
	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * @return the taste
	 */
	public String getTaste() {
		return taste;
	}
	/**
	 * @param taste the taste to set
	 */
	public void setTaste(String taste) {
		this.taste = taste;
	}
	
	@Override
	public String toString() {
		return "Apple [weight=" + weight + ", color=" + color + ", taste=" + taste + "]";
	}



	
	
	

}
