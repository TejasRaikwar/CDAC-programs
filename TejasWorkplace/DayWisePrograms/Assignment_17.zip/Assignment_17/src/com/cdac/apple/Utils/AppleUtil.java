package com.cdac.apple.Utils;

import java.util.ArrayList;
import java.util.List;

import com.cdac.apple.Apple;

public class AppleUtil {
	public static List<Apple> getApple(){
		List<Apple> apples=new ArrayList<Apple>();
		
		apples.add(new Apple(30.00,"green","sweet"));
		apples.add(new Apple(50.00,"red","sour"));
		apples.add(new Apple(40.00,"green","sweet"));
		apples.add(new Apple(31.00,"red","tastless"));
		apples.add(new Apple(32.00,"red","tastless"));
		apples.add(new Apple(36.00,"green","sour"));
		apples.add(new Apple(35.00,"red","sweet"));
		apples.add(new Apple(39.00,"red","sour"));
		apples.add(new Apple(42.00,"green","sour"));
		apples.add(new Apple(46.00,"red","sweet"));
		apples.add(new Apple(65.00,"yellow","sour"));
		apples.add(new Apple(70.00,"yellow","sweet"));
		
		return apples;
	}

}
