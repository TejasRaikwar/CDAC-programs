

//BookAddfile.java
package com.cdac.library.objects;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cdac.library.enums.BookType;

public class BookAddfile {

 public static void copyFileToAnother(List<Book> books, String fileName) {
     try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(fileName))) {
         for (Book b : books) {
             dos.writeUTF(b.getTitle());
             dos.writeUTF(b.getAuthorName());
             dos.writeUTF(b.getBookType().toString());
             dos.writeUTF(b.getPublishedDate().toString());
             dos.writeDouble(b.getPrice());
             dos.writeInt(b.getQuantity());
         }
       
     } catch (IOException e) {
         System.out.println("Error writing file: " + e.getMessage());
     }
 }

 public static List<Book> readFile(String fileName) {
     List<Book> books = new ArrayList<>();
     try (DataInputStream dis = new DataInputStream(new FileInputStream(fileName))) {
         while (dis.available() > 0) {
             String title = dis.readUTF();
             String author = dis.readUTF();
             BookType bookType = BookType.valueOf(dis.readUTF());
             String dateStr = dis.readUTF();

             if (dateStr == null || dateStr.isBlank()) {
                 System.out.println("Invalid date string found, skipping book: " + title);
                 continue;
             }

             LocalDate date = LocalDate.parse(dateStr);
             double price = dis.readDouble();
             int quantity = dis.readInt();

             Book book = new Book(title, bookType, price, dateStr, author, quantity);
             books.add(book);
         }
         System.out.println("Books loaded from file.");
     } catch (IOException e) {
         System.out.println("Error reading file: " + e.getMessage());
     }
     return books;
 }
}

