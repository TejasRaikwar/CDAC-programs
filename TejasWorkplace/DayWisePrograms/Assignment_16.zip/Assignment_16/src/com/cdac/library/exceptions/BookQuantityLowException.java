package com.cdac.library.exceptions;

public class BookQuantityLowException extends Exception{
	public BookQuantityLowException(String msg){
		super(msg);
	}
}
