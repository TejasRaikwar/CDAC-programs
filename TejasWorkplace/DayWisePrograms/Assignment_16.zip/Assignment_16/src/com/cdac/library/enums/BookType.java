package com.cdac.library.enums;

public enum BookType {
	SCI_FI,
	COMEDY,
	HORROR,
	FICTION,
	NON_FICTION,
	FANTASY,
	THRILLER;
}
