package com.cdac.library.tester;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cdac.library.enums.BookType;
import com.cdac.library.exceptions.BookNotFoundException;
import com.cdac.library.exceptions.BookQuantityLowException;
import com.cdac.library.exceptions.DuplicateBooksException;
import com.cdac.library.objects.Book;
import com.cdac.library.objects.BookAddfile;
import com.cdac.library.utils.BooksUtil;

public class LibraryHashMap {

    public static void main(String[] args) {
    	List<Book> books = new ArrayList<>();
		books.addAll(BooksUtil.getBooks());
		  File file = new File("books.dat");
		Scanner sc = new Scanner(System.in);

         int ch;
         do {
            System.out.println("\nEnter Option : ");
            System.out.println("1. Add book.");
            System.out.println("2. Display All books.");
            System.out.println("3. Allot book to student.");
            System.out.println("4. Take book return.");
            System.out.println("5. Remove book.");
            System.out.println("6. Write Books to File.");
            System.out.println("7. Read Books from File.");
            System.out.println("0. Exit Application.");

            ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1: {
                     
                        System.out.println("Enter Book title: ");
                        String title = sc.nextLine();

                        System.out.println("Enter Book Type (e.g., FICTION): ");
                        String booktype = sc.nextLine();

                        System.out.println("Enter Book Price: ");
                        double price = sc.nextDouble();
                        sc.nextLine();

                        System.out.println("Enter Published Date (yyyy-MM-dd): ");
                        String pubDate = sc.nextLine();

                        System.out.println("Enter Author Name: ");
                        String author = sc.nextLine();

                        System.out.println("Enter Quantity: ");
                        
                        int qty = sc.nextInt();
                        sc.nextLine();

                     try {
                    	 Book bk = new Book(title, BookType.valueOf(booktype.toUpperCase()), price, pubDate, author,
                    			 qty);
     					addBook(books, bk);
     				} catch (DuplicateBooksException e) {
     					System.out.println(e.getMessage());
     				}

                     break;
                }

                case 2:{
                	for (Book book : books) {
    					System.out.println(book);
    				}
                    break;	
    			}
            
                case 3:
                {
                	System.out.println("Enter Book Title to Allot : ");
				String booktitle = sc.nextLine();
				try {
					if (allotBook(books, booktitle)) {
						System.out.println("Collect Book");
					}
				} catch (BookNotFoundException | BookQuantityLowException e) {
					System.out.println(e.getMessage());
				}
				break;
			}
                case 4: {
    				System.out.println("Enter Book Title to Return : ");
    				String booktitle = sc.nextLine();
    				try {
    					if (returnBook(books, booktitle)) {
    						System.out.println("Thank you for returning Book");
    					}
    				} catch (BookNotFoundException | BookQuantityLowException e) {
    					System.out.println(e.getMessage());
    				}

    				break;
    			}

                case 5:  {
    				System.out.println("Enter Book Title to Return : ");
    				String booktitle = sc.nextLine();
    				try {
    					if (removeBook(books, booktitle)) {
    						System.out.println("Book Successfully Removed from Library");
    					}
    				} catch (BookNotFoundException e) {
    					System.out.println(e.getMessage());
    				}

    				break;
                }
    			

                case 6:
                    BookAddfile.copyFileToAnother(books, file.getAbsolutePath());
                    System.out.println("Books saved to file.");
                    break;

                case 7:
                    List<Book> booksFromFile = BookAddfile.readFile(file.getAbsolutePath());
                    booksFromFile.forEach(System.out::println);
                    break;

                case 0:
                    System.out.println("Thank you for visiting the Library.");
                    break;

                default:
                    System.out.println("Invalid option.");
            }

        } while (ch != 0);

        sc.close();
    }

    public static boolean addBook(List<Book> books, Book bk) throws DuplicateBooksException {
        if (books.contains(bk)) {
            throw new DuplicateBooksException("Book Already Present in Library");
        }
        books.add(bk);
        return true;
    }

   
   
    public static boolean allotBook(List<Book> books, String booktitle)
			throws BookNotFoundException, BookQuantityLowException {

		// Find the book by title
		Book book = null;
		for (Book b : books) {
			if (b.getTitle().equalsIgnoreCase(booktitle)) {
				book = b;
				break;
			}
		}

		if (book == null) {
			throw new BookNotFoundException("Book Not Found :: Please Enter the Correct title");
		}

		if (book.getQuantity() <= 0) {
			throw new BookQuantityLowException("Book Quantity Low :: Cannot allot the book");
		}

		book.setQuantity(book.getQuantity() - 1);
		return true;
	}

    public static boolean returnBook(List<Book> books, String booktitle)
			throws BookNotFoundException, BookQuantityLowException {

		// Find the book by title
		Book book = null;
		for (Book b : books) {
			if (b.getTitle().equalsIgnoreCase(booktitle)) {
				book = b;
				break;
			}
		}

		if (book == null) {
			throw new BookNotFoundException("Book Not Found :: Please Enter the Correct title");
		}

		book.setQuantity(book.getQuantity() + 1);
		return true;
	}

    public static boolean removeBook(List<Book> books, String title) throws BookNotFoundException {

		Book book = null;
		for (Book b : books) {
			if (b.getTitle().equals(title)) {
				book = b;
			}
		}
		if (book == null) {
			throw new BookNotFoundException("Book Not Found :: Please Enter the Correct title");
		}
		books.remove(book);
		return true;

	}


}
		


