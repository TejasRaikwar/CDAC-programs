package com.cdac.file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class CheckFile { 
public static void main(String [] args) {
	File file=new File("./ abc.txt");
	Scanner sc =new Scanner (System.in);
	
	if(file.exists()) {
		if(checkFileorDir(file)) {
			System.out.println("Enter option :\n1.Read File\n2.Copy File");
			int op = sc.nextInt();
			switch (op) {
			case 1: {
				readFile(file);
				break;
			}
			case 2: {
				File file2 = new File("./pqr.txt");
				copyFileToAnother(file, file2);
				break;

			}

			default: {
				System.out.println("Invalid Input");
			}
			}
		}

	} else {
		createNewFile(file);
	}
	sc.close();

}
	public static boolean checkFileorDir(File file) {
		if(file.isFile()) {
			System.out.println("abc is a file");
			return true;
		}
			else if(file.isDirectory())
			{        
				System.out.println("abc is a directory ");
				System.out.println("It contains");
				for(String s:file.list()) {
					System.out.println(s);
			}
		}
		return false;
	}
	public static void createNewFile(File file) {
		try {
			if (file.createNewFile()) {
				System.out.println("File Created");
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	public static void readFile(File file) {
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(file));) {
			String text;
			bufferedReader.readLine();
			while ((text = bufferedReader.readLine()) != null) {
				System.out.println(text);
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

	}

	public static void copyFileToAnother(File file, File file2) {
		try (PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter(file2)));
				BufferedReader bufferedReader = new BufferedReader(new FileReader(file));) {
			String text;
			while ((text = bufferedReader.readLine()) != null) {
				printWriter.println(text);}

			System.out.println("Copy Successfully");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		
	
}
}
                                  