package com.cdac.Printer.objects;

import java.io.*;
import java.util.HashMap;

public class PrintFileHandler {
    private static final String FILE_NAME = "printers.dat";

    public static void savePrinters(HashMap<String, Printer> printers) {
        try (ObjectOutputStream out =
                new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            out.writeObject(printers);
        } catch (IOException e) {
            System.err.println("Error saving printers: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public static HashMap<String, Printer> loadPrinters() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return new HashMap<>();

        try (ObjectInputStream in =
                new ObjectInputStream(new FileInputStream(file))) {
            return (HashMap<String, Printer>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading printers: " + e.getMessage());
            return new HashMap<>();
        }
    }
}
