package com.cdac.Printer.utils;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import com.cdac.Printer.objects.Printer;
import com.cdac.Printer.enums.PrinterType;

public class PrinterUtil {

    // Preload sample printers
    public static HashMap<String, Printer> getSamplePrinters() {
        HashMap<String, Printer> printers = new HashMap<>();

        Printer p1 = new Printer("P001", "HP-Laser200", 15000.0, PrinterType.LASER, "2021-09-12");
        printers.put(p1.getSerialNo(), p1);

        Printer p2 = new Printer("P002", "Canon-InkX", 12000.0, PrinterType.INKJET, "2022-11-05");
        printers.put(p2.getSerialNo(), p2);

        Printer p3 = new Printer("P003", "Epson-DotPro", 8000.0, PrinterType.DOTMATRIX, "2021-07-20");
        printers.put(p3.getSerialNo(), p3);

        Printer p4 = new Printer("P004", "Brother-InkJet500", 11000.0, PrinterType.INKJET, "2024-02-15");
        printers.put(p4.getSerialNo(), p4);

        Printer p5 = new Printer("P005", "Xerox-LaserPlus", 20000.0, PrinterType.LASER, "2023-09-30");
        printers.put(p5.getSerialNo(), p5);

        return printers;
    }

    // Add a new printer
    public static void addPrinter(HashMap<String, Printer> printers, String serialNo, String model, 
                                  double price, PrinterType type, String manufacturingDate) {
        Printer newPrinter = new Printer(serialNo, model, price, type, manufacturingDate);
        printers.put(serialNo, newPrinter);
    }

    // Update the price of an existing printer
    public static boolean updatePrice(HashMap<String, Printer> printers, String serialNo, double newPrice) {
        Printer printer = printers.get(serialNo);
        if (printer != null) {
            printer.setPrice(newPrice);
            return true;
        }
        return false;
    }

    // Print all printers
   
    public static void printAll(Map<String, Printer> printers) {
        printers.values().stream()
            .sorted(Comparator.comparing(Printer::getSerialNo)) // or sort by model, price, etc.
            .forEach(System.out::println);
    }
}

