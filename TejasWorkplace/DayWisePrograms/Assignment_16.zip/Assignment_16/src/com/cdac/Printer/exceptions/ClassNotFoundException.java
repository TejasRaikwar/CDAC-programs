package com.cdac.Printer.exceptions;

public class ClassNotFoundException extends Exception {
	public ClassNotFoundException (String msg) {
		super(msg);
	}

}

