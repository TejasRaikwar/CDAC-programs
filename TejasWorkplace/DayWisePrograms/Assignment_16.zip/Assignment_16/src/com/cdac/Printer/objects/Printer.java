
//2) Create Printer class with serialNo, modelNo, price, printerType, manufacturingDate. Create Enum for PrinterType with values as LASER, INKJET, DOTMATRIX.
// 
//Store the printers objects in file using ObjectOutputStream. On program startup read all printers from file and store them in HashMap where serialNo will be key and printer object will be value.
// 
// 1.Add Printer
// 2.Update Printer Price
// 3.Print all Printers

package com.cdac.Printer.objects;
import java.time.LocalDate;

import com.cdac.Printer.enums.PrinterType;
import com.cdac.library.utils.DateUtils;

import java.io.Serializable;

public class Printer implements Serializable  {
	private static final long serialVersionUID = 9152151241480164680L;
	private String serialNo;
	private String  modelNo;
	private double price;
	private PrinterType printerType;
	private LocalDate manufacturingDate;
	
	public Printer() {
		super();
	}

	public Printer(String serialNo, String modelNo, double price, PrinterType printerType,
			String manufacturingDate) {
		super();
		this.serialNo = serialNo;
		this.modelNo = modelNo;
		this.price = price;
		this.printerType = printerType;
		this.manufacturingDate = DateUtils.getLocalDate(manufacturingDate);
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public String getModelNo() {
		return modelNo;
	}

	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public PrinterType getPrinterType() {
		return printerType;
	}

	public void setPrinterType(PrinterType printerType) {
		this.printerType = printerType;
	}

	public LocalDate getManufacturingDate() {
		return manufacturingDate;
	}

	public void setManufacturingDate(LocalDate manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}
	public String getStringPublishedDate() {
		return DateUtils.getStringLocalDate(manufacturingDate);
	}
	public void setStringPublishedDate(String manufacturingDate) {
		this.manufacturingDate = DateUtils.getLocalDate(manufacturingDate);
	}
	

	@Override
	public String toString() {
		return "Printer [serialNo=" + serialNo + ", modelNo=" + modelNo + ", price=" + price + ", printerType="
				+ printerType + ", manufacturingDate=" + manufacturingDate + "]";
	}

}
