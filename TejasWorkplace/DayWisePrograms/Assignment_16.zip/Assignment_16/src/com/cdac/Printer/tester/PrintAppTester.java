package com.cdac.Printer.tester;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Scanner;
import com.cdac.Printer.enums.PrinterType;
import com.cdac.Printer.objects.Printer;
import com.cdac.Printer.objects.PrintFileHandler;
import com.cdac.Printer.utils.PrinterUtil;

public class PrintAppTester {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HashMap<String, Printer> printers = PrintFileHandler.loadPrinters();

        // Preload sample if empty
        if (printers.isEmpty()) {
            printers.putAll(PrinterUtil.getSamplePrinters());
            PrintFileHandler.savePrinters(printers);
        }

        int choice;
        do {
            System.out.println("\n1. Add Printer\n2. Update Printer Price\n3. Print All Printers\n0. Exit");
            System.out.println("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume the newline character

            switch (choice) {
                case 1: {
                    System.out.println("Enter Serial No: ");
                    String id = sc.nextLine();
                    System.out.println("Enter Model No: ");
                    String model = sc.nextLine();
                    System.out.println("Enter Price: ");
                    double price = sc.nextDouble();
                    sc.nextLine(); // consume the newline character
                    System.out.println("Enter Printer Type (LASER, INKJET, DOTMATRIX): ");
                    PrinterType type = PrinterType.valueOf(sc.nextLine().toUpperCase());
                    System.out.println("Enter Manufacturing Date ");
                    String date = sc.nextLine();

                    // Add printer to the map
                    PrinterUtil.addPrinter(printers, id, model, price, type, date);
                    System.out.println(" Printer Added Successfully");
                   
                    break;
                }
                case 2: {
                    System.out.println("Enter Serial No: ");
                    String id = sc.nextLine();
                    System.out.println("Enter New Price: ");
                    double newPrice = sc.nextDouble();
                    sc.nextLine(); // consume the newline character

                    // Update printer price
                    if (PrinterUtil.updatePrice(printers, id, newPrice)) {
                        PrintFileHandler.savePrinters(printers);
                        System.out.println("Updated Successfully");
                    } else {
                        System.out.println("Printer not found.");
                    }
                    break;
                }
                case 3: {
                    // Print all printers
                    PrinterUtil.printAll(printers);
                    break;
                }
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 0);

        sc.close();
    }
}
