package com.cdac.Printer.enums;

public enum PrinterType {
 LASER,
 INKJET,
 DOTMATRIX;
 
}
